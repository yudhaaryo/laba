package com.yudhaaryosapplication.app.modules.landingpage.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.yudhaaryosapplication.app.R
import com.yudhaaryosapplication.app.appcomponents.base.BaseActivity
import com.yudhaaryosapplication.app.databinding.ActivityLandingpageBinding
import com.yudhaaryosapplication.app.modules.landingpage.`data`.viewmodel.LandingpageVM
import com.yudhaaryosapplication.app.modules.login.ui.LoginActivity
import kotlin.String
import kotlin.Unit

class LandingpageActivity : BaseActivity<ActivityLandingpageBinding>(R.layout.activity_landingpage)
    {
  private val viewModel: LandingpageVM by viewModels<LandingpageVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.landingpageVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.linearIPhone8One.setOnClickListener {
      val destIntent = LoginActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "LANDINGPAGE_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, LandingpageActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
